export const CDN_BASE_URL = "https://cdn.loldata.cc/15.13.1";

export const champPath = `${CDN_BASE_URL}/img/champion`;
